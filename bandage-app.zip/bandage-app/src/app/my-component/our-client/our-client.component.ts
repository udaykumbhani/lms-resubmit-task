import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-client',
  templateUrl: './our-client.component.html',
  styleUrls: ['./our-client.component.scss']
})
export class OurClientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
