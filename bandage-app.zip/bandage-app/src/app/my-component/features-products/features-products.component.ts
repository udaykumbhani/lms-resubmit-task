import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-features-products',
  templateUrl: './features-products.component.html',
  styleUrls: ['./features-products.component.scss']
})
export class FeaturesProductsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
