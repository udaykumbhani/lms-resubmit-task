import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarTopComponent } from './my-component/navbar-top/navbar-top.component';
import { MyComponentComponent } from './my-component/my-component.component';
import { HeaderComponent } from './my-component/header/header.component';
import { HeroComponent } from './my-component/hero/hero.component';
import { OurClientComponent } from './my-component/our-client/our-client.component';
import { ProductCardComponent } from './my-component/product-card/product-card.component';
import { FeaturesProductsComponent } from './my-component/features-products/features-products.component';
import { WhatWeDoComponent } from './my-component/what-we-do/what-we-do.component';
import { OurServicesComponent } from './my-component/our-services/our-services.component';
import { FeaturedPostComponent } from './my-component/featured-post/featured-post.component';
import { FooterComponent } from './my-component/footer/footer.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarTopComponent,
    MyComponentComponent,
    HeaderComponent,
    HeroComponent,
    OurClientComponent,
    ProductCardComponent,
    FeaturesProductsComponent,
    WhatWeDoComponent,
    OurServicesComponent,
    FeaturedPostComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
