$(document).ready(function(){
    $('.slider').slick({
        dots: true,
        arrows: false,
        // infinite: true,
        // speed: 300,
        slidesToScroll: 1,
        slidesToShow: 2,
        // centerMode: true,
        // variableWidth: true,
        autoplay: true,
        autoplaySpeed: 2000,
    });
});
